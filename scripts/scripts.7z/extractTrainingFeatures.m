function features = extractTrainingFeatures(id, featureMatrix)

features = featureMatrix(id(:), :);

end
